package ipca.projeto.projetoquiz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ResultActivity: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.score1)

        val username = intent.getStringExtra(Constants.USER_NAME)
        val nome : TextView = findViewById(R.id.nomefimtextview)
        val score : TextView = findViewById(R.id.score)
        val finishbutton : Button = findViewById(R.id.finishButton)
        nome.text = username
        val totalQuestions = intent.getIntExtra(Constants.TOTAL_QUESTIONS,0)
        val correctAnswers = intent.getIntExtra(Constants.CORRECT_ANSWERS,0)
        score.text = "Acertaste $correctAnswers de $totalQuestions perguntas"
        finishbutton.setOnClickListener{
            startActivity(Intent(this,MainActivity::class.java))
        }



    }

}