package ipca.projeto.projetoquiz

data class Question(
    val questionText: String,
    val options: List<String>,
    val correctOption: Int
)