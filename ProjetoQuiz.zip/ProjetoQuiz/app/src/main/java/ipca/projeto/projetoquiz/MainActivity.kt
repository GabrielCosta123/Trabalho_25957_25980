package ipca.projeto.projetoquiz


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast


open class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val playButton: Button = findViewById(R.id.playButton)
        val nometext: TextView = findViewById(R.id.nometextview)

        playButton.setOnClickListener {
            if (nometext.text.toString().isEmpty()) {
                Toast.makeText(this, "Escreve o teu nome", Toast.LENGTH_SHORT).show()
            } else {
                val intent = Intent(this, QuestionActivity::class.java)
                intent.putExtra(Constants.USER_NAME, nometext.text.toString())
                startActivity(intent)
                finish()
            }

        }
    }
}