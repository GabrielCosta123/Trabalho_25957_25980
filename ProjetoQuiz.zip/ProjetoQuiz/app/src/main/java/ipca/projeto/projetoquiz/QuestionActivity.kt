package ipca.projeto.projetoquiz

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat


class QuestionActivity : AppCompatActivity(), View.OnClickListener {

    private var mQuestionsList: ArrayList<Question>? = null
    private var mSelectedOptionPosition: Int = 0
    private var mCurrentPosition: Int = 1
    private lateinit var questiontextview: TextView
    private lateinit var opt1: Button
    private lateinit var opt2: Button
    private lateinit var opt3: Button
    private lateinit var opt4: Button
    private lateinit var submitbutton: Button
    private var mCorrectAnswers: Int = 0
    private var mUserName: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.questions_tab)

        mUserName = intent.getStringExtra(Constants.USER_NAME)

        questiontextview = findViewById(R.id.questiontextview)
        opt1 = findViewById(R.id.option1)
        opt2 = findViewById(R.id.option2)
        opt3 = findViewById(R.id.option3)
        opt4 = findViewById(R.id.option4)
        submitbutton = findViewById(R.id.submitbutton)

        mQuestionsList = Constants.getQuestions()

        setQuestion()


    }

    private fun setQuestion() {

        val question = mQuestionsList!![mCurrentPosition - 1]

        defaultOptionsView()
        if (mCurrentPosition == mQuestionsList!!.size) {
            submitbutton.text = "FIM"
        } else {
            submitbutton.text = "Confirmar"
        }
        opt1.setOnClickListener(this)
        opt2.setOnClickListener(this)
        opt3.setOnClickListener(this)
        opt4.setOnClickListener(this)
        submitbutton.setOnClickListener(this)


        questiontextview.text = question!!.questionText
        opt1.text = question!!.options[0]
        opt2.text = question!!.options[1]
        opt3.text = question!!.options[2]
        opt4.text = question!!.options[3]


    }

    private fun defaultOptionsView() {
        val options = ArrayList<Button>()
        options.add(0, opt1)
        options.add(1, opt2)
        options.add(2, opt3)
        options.add(3, opt4)

        for (option in options) {
            option.setTextColor(Color.parseColor("#7A8089"))
            option.typeface = Typeface.DEFAULT

        }
    }

    override fun onClick(v: View?) {
        when (v?.id) {
            R.id.option1 -> {
                selectedOptionView(opt1, 1)
            }

            R.id.option2 -> {
                selectedOptionView(opt2, 2)
            }

            R.id.option3 -> {
                selectedOptionView(opt3, 3)
            }

            R.id.option4 -> {
                selectedOptionView(opt4, 4)
            }

            R.id.submitbutton -> {
                if (mSelectedOptionPosition == 0) {
                    mCurrentPosition++

                    when {
                        mCurrentPosition <= mQuestionsList!!.size -> {
                            setQuestion()
                        }

                        else -> {
                            val intent = Intent(this, ResultActivity::class.java)
                            intent.putExtra(Constants.USER_NAME, mUserName)
                            intent.putExtra(Constants.CORRECT_ANSWERS,mCorrectAnswers)
                            intent.putExtra(Constants.TOTAL_QUESTIONS,mQuestionsList!!.size)
                            startActivity(intent)
                        }
                    }
                } else {
                    val question = mQuestionsList?.get(mCurrentPosition - 1)
                    if (question!!.correctOption != mSelectedOptionPosition) {
                        answerView(mSelectedOptionPosition, Color.RED)
                    } else {
                        mCorrectAnswers++
                    }
                    answerView(question.correctOption, Color.GREEN)
                    if (mCurrentPosition == mQuestionsList!!.size) {
                        submitbutton.text = "FIM"
                    } else {
                        submitbutton.text = " Próxima Pergunta! "
                    }
                    mSelectedOptionPosition = 0
                }
            }
        }
    }


    private fun answerView(answer: Int, textColor: Int) {
        when (answer) {
            1 -> {
                opt1.setTextColor(textColor)
            }

            2 -> {
                opt2.setTextColor(textColor)
            }

            3 -> {
                opt3.setTextColor(textColor)
            }

            4 -> {
                opt4.setTextColor(textColor)
            }
        }
    }

    private fun selectedOptionView(button: Button, selectedOptionNum: Int) {
        defaultOptionsView()
        mSelectedOptionPosition = selectedOptionNum
        button.setTypeface(button.typeface, Typeface.BOLD)


    }
}


