package ipca.projeto.projetoquiz

object Constants {
    const val USER_NAME: String = "user_name"
    const val TOTAL_QUESTIONS: String ="total_questions"
    const val CORRECT_ANSWERS: String="correct_answers"
    fun getQuestions(): ArrayList<Question>{
        val questionsList = ArrayList<Question>()

        val que1 = Question("Quem foi o primeiro presidente dos Estados Unidos?",listOf("Thomas Jefferson", "George Washington", "Abraham Lincoln", "John Adams"),2)
        questionsList.add(que1)
        val que2 = Question( "Qual evento marcou o início da Primeira Guerra Mundial em 1914?", listOf("Bombardeio de Pearl Harbor", "Assassinato de Franz Ferdinand", "Tratado de Versalhes", "Queda do Império Austro-Húngaro"),2)
        questionsList.add(que2)
        val que3 = Question("Quem foi o líder da Revolução Russa em 1917?",listOf("Josef Stalin", "Vladimir Lenin", "Leon Trotsky", "Alexander Kerensky"),2)
        questionsList.add(que3)
        val que4 = Question("Qual foi a capital do Império Romano?", listOf("Alexandria", "Atenas", "Constantinopla", "Roma"), 4)
        questionsList.add(que4)
        val que5 = Question("Qual foi o evento que desencadeou a entrada dos Estados Unidos na Segunda Guerra Mundial?", listOf("Ataque a Pearl Harbor", "Batalha de Stalingrado", "Bombas de Hiroshima e Nagasaki", "Invasão da Polônia"), 1)
        questionsList.add(que5)
        val que6 = Question(" Qual foi o tratado que encerrou a Primeira Guerra Mundial em 1919?", listOf("Tratado de Versalhes", "Tratado de Tordesilhas", "Tratado de Brest-Litovski", "Tratado de Paris"),1 )
        questionsList.add(que6)
        val que7 = Question("Quem foi o primeiro faraó do Antigo Egito unificado?", listOf("Ramsés II","Tutancâmon", "Menés", "Cleópatra"),3)
        questionsList.add(que7)
        val que8 = Question( "Quem foi o primeiro rei de Portugal?", listOf("Dom Sancho I", "Dom Afonso I (Afonso Henriques)", "Dom Pedro I", "Dom João I"),2 )
        questionsList.add(que8)
        val que9 = Question("Quem foi o rei responsável pela construção da Universidade de Coimbra em 1290?", listOf("Dom Fernando I", "Dom Dinis", "Dom João III", "Dom Manuel I"), 2)
        questionsList.add(que9)
        val que10 = Question("Quem liderou a Revolução Chinesa e estabeleceu a República Popular da China em 1949?", listOf("Mao Zedong", "Sun Yat-sen", "Chiang Kai-shek", "Deng Xiaoping"), 1)
        questionsList.add(que10)
        return questionsList


    }

}