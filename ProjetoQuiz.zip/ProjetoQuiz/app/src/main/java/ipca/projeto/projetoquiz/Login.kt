package ipca.projeto.projetoquiz

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth


class Login:AppCompatActivity(){

    private lateinit var auth: FirebaseAuth

    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.log_in)

        auth = FirebaseAuth.getInstance()

        val signintext : TextView = findViewById(R.id.signintextview)
        signintext.setOnClickListener {
            val intent = Intent(this, Signin::class.java)
            startActivity(intent)
        }

        val buttonlogin : Button = findViewById(R.id.buttonlogin)
        buttonlogin.setOnClickListener {
            login()

        }



    }
    private fun login(){
        val email: EditText = findViewById(R.id.emaillogintext)
        val password: EditText = findViewById(R.id.passwordlogintext)

        if(email.text.isEmpty() || password.text.isEmpty()){
            Toast.makeText(this, "Please fill all the fields", Toast.LENGTH_SHORT).show()
            return
        }
        val emailInput = email.text.toString()
        val passwordInput = password.text.toString()

        auth.signInWithEmailAndPassword(emailInput, passwordInput).addOnCompleteListener(this) { task ->
            if(task.isSuccessful){
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                Toast.makeText(baseContext,"Success",Toast.LENGTH_SHORT).show()

            }else{
                Toast.makeText(baseContext,"Authentication failed",Toast. LENGTH_SHORT).show()
            }
        }
            .addOnFailureListener {
                Toast.makeText(baseContext, "Authentication failed ${it.localizedMessage}", Toast.LENGTH_SHORT).show()
            }
    }
}
